const GlobalFooter = () => {
  return <div></div>
};

export default GlobalFooter;
