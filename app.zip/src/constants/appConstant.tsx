export const APP_TITLE = 'Pet Adoption';

export const APP_SUB_TITLE = 'Pet Adoption';


export const APP_LOGO = null;
